using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using System.Text;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme).AddJwtBearer(
    options =>
    {
        options.TokenValidationParameters = new Microsoft.IdentityModel.Tokens.TokenValidationParameters
        {
            ValidateAudience = true, //izin verilen sitelerin denetle diyoruz
            ValidateIssuer = true,//hangi sitenin denetleyip denetlemeyece�ini soruyor. �zin verdim
            ValidateLifetime = true,//Token'�n ya�am s�residir. Token'� belirli s�rede de�i�mek laz�m g�venlik i�in.
            ValidateIssuerSigningKey = true,//Token'�n bize ait olup olmad���n� kontrol eder. 
            //Yukar�daki izinler verildikten sonra appsetting.json'da bunlar�n de�erleri girilir.
            ValidIssuer = builder.Configuration["Token:Issuer"],
            ValidAudience = builder.Configuration["Token:Audience"],
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(builder.Configuration["Token:SecurityKey"])),
            ClockSkew = TimeSpan.Zero//token �zerine ekstra s�re ekleyip eklemeyece�ini belirtirsin.
        };
    });

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthentication();//token kulland���m�z i�in ekleriz
app.UseAuthorization();


app.MapControllers();

app.Run();
