﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Net.Http.Headers;
using W4.Security;

namespace W4.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {
        private readonly IConfiguration _configuration;

        public ValuesController(IConfiguration configuration) 
        {
            _configuration = configuration;
        }
        [HttpGet]
        public IActionResult Get()
        {
           Token token = TokenHandlar.CreateToken(_configuration,"apitest","test123");

           var client = new HttpClient();

         
            return Ok(token);
        }
        // client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token.AccessToken);//Access token'ı header'a ekle.

        // var response = client.GetAsync("https://jsonplaceholder.typicode.com/todos/1").Result; //api isteğini gönder.
        //if (response.IsSuccessStatusCode)//Yanıtı işle
        //{
        //    // ...
        //}
        //else
        //{
        //    // ...
        //}

        //if (response.StatusCode == StatusCodes.Unauthorized) //Refresh token süresi dolduğunda yeni access token almak için
        //{
        //    var newAccessToken = TokenHandlar.CreateToken(_configuration, "apitest", "test123");
        //    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", newAccessToken.AccessToken);
        //    response = client.GetAsync("https://api.example.com/api/v1/data").Result;
        //}


    }
}
